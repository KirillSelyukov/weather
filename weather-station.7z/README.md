- Use proxy wich provide CORS access to server on port:8080
to use proxyuse command  node ./proxy.js from ./src/proxy folder